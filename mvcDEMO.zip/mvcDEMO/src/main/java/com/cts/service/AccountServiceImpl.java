package com.cts.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.bean.Account;
import com.cts.dao.AccountDAO;

@Service("AccountService")
@Transactional
public class AccountServiceImpl implements AccountService{

	@Autowired
	public AccountDAO accountDAO;
	
	public boolean registerUser(Account account) {
		return accountDAO.registerUser(account);
	}

	public Account loginUser(String username,String password) {
		return accountDAO.loginUser(username,password);
	}


	
}
