package com.cts.service;

import com.cts.bean.Account;

public interface AccountService {

	public boolean registerUser(Account account);
	public Account loginUser(String username,String password);
}
