package com.cts.dao;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cts.bean.Account;

@Repository("AccountDAO")
public class AccountDAOImpl implements AccountDAO{

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	@Transactional
	public boolean registerUser(Account account) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		session.save(account);
		return true;
	}

	@Override
	public Account loginUser(String username, String password) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Account where username=? and password=?");
		query.setParameter(0,username);
		query.setParameter(1,password);
		Account account=(Account)query.getSingleResult();
		return account;
	}

}
