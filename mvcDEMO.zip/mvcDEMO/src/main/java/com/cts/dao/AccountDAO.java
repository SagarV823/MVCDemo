package com.cts.dao;

import com.cts.bean.Account;

public interface AccountDAO {

	public boolean registerUser(Account account);
	public Account loginUser(String username,String password);
	
}
