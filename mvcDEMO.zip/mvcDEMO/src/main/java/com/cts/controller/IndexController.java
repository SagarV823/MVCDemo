package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bean.Account;
import com.cts.service.AccountService;

@Controller
public class IndexController {
	
	@Autowired
	AccountService accountService;
	
	@RequestMapping(value="/")
	public String welcomePage()
	{
		return "Register";
	}
	
	@RequestMapping(value="registerUser",method=RequestMethod.GET)
	public ModelAndView RegisterUser(@ModelAttribute Account account){
		boolean result=accountService.registerUser(account);
		ModelAndView mv=new ModelAndView();
		if(result)
		{
			mv.setViewName("Success");
		}
		else
		{
			mv.setViewName("Failed");
		}
		return mv;
	}
	
	@RequestMapping(value="loginUser",method=RequestMethod.POST)
	public ModelAndView LoginUser(@RequestParam ){
		boolean result=accountService.registerUser(account);
		ModelAndView mv=new ModelAndView();
		if(result)
		{
			mv.setViewName("Success");
		}
		else
		{
			mv.setViewName("Failed");
		}
		return mv;
	}
	
	
}
